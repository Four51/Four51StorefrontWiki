using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Net;
using System.Reflection;
using System.Security;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using System.Web;
using Pageflex.Scripting;
using IDAutomation.IntelligentMail;
using IDAutomation.NetAssembly;

namespace Four51
{
	public class Actions
	{

	#region Public Methods

		public static void Add(object NumberA, object NumberB, string SpecName, object NumberFormatCode, object ErrorMessage)
		{
			Break();
			try
			{
				double z = N(NumberA) + N(NumberB);
				Variable(SpecName).Value = z.ToString((string)NumberFormatCode);
			}
			catch (Exception ex)
			{
				throw new Four51ActionsException(ex.Message, (string)ErrorMessage);
			}
		}

		public static void MultiAdd(object Numbers, string SpecName, object NumberFormatCode, object ErrorMessage)
		{
			Break();
			try
			{
				double count = 0;
				object[] numbers = ParseArray(Numbers);
				foreach (object n in numbers)
				{
					count += N(n);
				}
				Variable(SpecName).Value = count.ToString((string)NumberFormatCode);
			}
			catch (Exception ex)
			{
				throw new Four51ActionsException(ex.Message, (string)ErrorMessage);
			}
		}

		public static void Bold(string SpecName, object Character, object ErrorMessage)
		{
			Break();
			try
			{
				Variable(SpecName).Value = Variable(SpecName).Value.Replace((string)Character, String.Format("<_char bold='true'>{0}</_char>", (string)Character));
			}
			catch (Exception ex)
			{
				throw new Four51ActionsException(ex.Message, (string)ErrorMessage);
			}
		}

		public static void CharacterCount(string SpecName, object Text, object CharacterToFind, object StartPosition, object ErrorMessage)
		{
			Break();
			try
			{
				var begin = ((string)Text).Length;
				var end = ((string)Text).Replace((string)CharacterToFind, String.Empty).Length;
				var result = begin - end;
				Variable(SpecName).Value = result.ToString();
			}
			catch (Exception ex)
			{
				throw new Four51ActionsException(ex.Message, (string)ErrorMessage);
			}
		}

		public static void Code39(string SpecName, object ErrorMessage)
		{
			Break();
			try
			{
				Variable(SpecName).Value = String.Format("*{0}*", Variable(SpecName).Value.Replace(" ", "_"));
			}
			catch (Exception ex)
			{
				throw new Four51ActionsException(ex.Message, (string)ErrorMessage);
			}
		}
		
		public static void Code39FullASCII(string SpecName, object ErrorMessage)
		{
			Break();
			try
			{
				char[] chars = Variable(SpecName).Value.ToCharArray();
				string barcode = String.Empty;

				for (int i = 0; i <= chars.GetUpperBound(0); i++)
				{
					double value = Convert.ToInt32(chars[i]);
					if (Char.IsNumber(chars[i]) || Char.IsUpper(chars[i]) || value == 45 || value == 46)
						barcode += chars[i].ToString();
					else if (value == 0)
						barcode += "%U";
					else if (value >= 1 && value <= 26)
						barcode += "$" + ((char)(value + 64)).ToString();
					else if (value >= 27 && value <= 31)
						barcode += "%" + ((char)(value + 38)).ToString();
					else if (value == 32)
						barcode += "_";
					else if (value >= 33 && value <= 44)
						barcode += "/" + ((char)(value + 32)).ToString();
					else if (value == 47)
						barcode += "/O";
					else if (value == 58)
						barcode += "/Z";
					else if (value >= 59 && value <= 63)
						barcode += "%" + ((char)(value + 11)).ToString();
					else if (value == 64)
						barcode += "%V";
					else if (value >= 91 && value <= 95)
						barcode += "%" + ((char)(value - 16)).ToString();
					else if (value == 96)
						barcode += "%W";
					else if (value >= 97 && value <= 122)
						barcode += "+" + ((char)(value - 32)).ToString();
					else if (value >= 123 && value <= 126)
						barcode += "%" + ((char)(value - 43)).ToString();
					else if (value == 127)
						barcode += "%T";
					else
						throw new Four51ActionsException("An invalid character not in the ASCII table was referenced.");
				}

				Variable(SpecName).Value = String.Format("*{0}*", barcode);
			}
			catch (Exception ex)
			{
				throw new Four51ActionsException(ex.Message, (string)ErrorMessage);
			}
		}
		
		public static void Compare(string SpecName, object CompareA, object CompareB, object ErrorMessage)
		{
			Break();
			try
			{
				Variable(SpecName).Value = CompareA.Equals(CompareB).ToString();
			}
			catch (Exception ex)
			{
				throw new Four51ActionsException(ex.Message, (string)ErrorMessage);
			}
		}

		public static void DefineBackgroundColor(object Element, object Color, object ColorType, object Definition, object Tint, object ErrorMessage)
		{
			Break();
			try
			{
				IFillStyle fill = (IFillStyle)Application.CurrentDocument.FindElement((string)Element);
				fill.FillColor = DefinedColor(Color, ColorType, Definition);
				fill.FillTint = (string)Tint == String.Empty ? 100 : N(Tint.ToString().Replace("%", ""));
			}
			catch (Pageflex.Scripting.Exceptions.ColorNotFoundException err)
			{
				throw new Four51ActionsException(err.Message);
			}
			catch (Exception ex)
			{
				throw new Four51ActionsException(ex.Message, (string)ErrorMessage);
			}
		}

		public static void DefineBorder(object Element, object Color, object ColorType, object Definition,
			object DashGap, object DashSize, object Thickness, object Tint,
			object ErrorMessage)
		{
			Break();
			try
			{
				IBorderStyle border = (IBorderStyle)Application.CurrentDocument.FindElement((string)Element);

				border.BorderColor = DefinedColor(Color, ColorType, Definition);
				border.BorderThickness = (string)Thickness == String.Empty ? "2.5pt" : Thickness.ToString().ToLower();
				border.BorderTint = (string)Tint == String.Empty ? 100 : N(Tint.ToString().Replace("%", ""));

				if (border.BorderStyle == BorderStyle.Dashed || border.BorderStyle == BorderStyle.Dotted)
				{
					border.BorderDashGap = (string)DashGap == String.Empty ? "5pt" : DashGap.ToString().ToLower();
					if (border.BorderStyle == BorderStyle.Dashed)
					{
						border.BorderDashSize = (string)DashSize == String.Empty ? "10pt" : DashSize.ToString().ToLower();
					}
				}
			}
			catch (Exception ex)
			{
				throw new Four51ActionsException(ex.Message, (string)ErrorMessage);
			}
		}

		public static void DefineParagraphStyle(object ParagraphStyle, object Font, object Alignment, object Size, object Italic, object Underline,
			object Bold, object BaselineShift, object Language, object Color, object ColorType, object Definition, object Tint, object ErrorMessage)
		{
			Break();
			try
			{
				ParagraphStyle chr = Application.CurrentDocument.GetParagraphStyle((string)ParagraphStyle);
				
				chr.Italic = (string)Italic == String.Empty ? false : Convert.ToBoolean(Italic);
				chr.Underline = (string)Underline == String.Empty ? false : Convert.ToBoolean(Underline);
				chr.Bold = (string)Bold == String.Empty ? false : Convert.ToBoolean(Bold);
				chr.TextTint = (string)Tint == String.Empty ? 100 : N(Tint.ToString().Replace("%", ""));

				if ((string)Alignment != String.Empty)
				{
					uint val;
					object type;

					bool IsNamed = !(UInt32.TryParse(Alignment.ToString(), out val));
					if (IsNamed)
						type = Enum.Parse(typeof(HorizontalAlignment), (string)Alignment, true);
					else
						type = (HorizontalAlignment)Convert.ToUInt32(Alignment);

					chr.Alignment = (HorizontalAlignment)type;
				}

				if ((string)Font != String.Empty)
					chr.FontFamily = Font.ToString();

				if ((string)Size != String.Empty)
					chr.FontSize = Size.ToString().ToLower();

				if ((string)BaselineShift != String.Empty)
					chr.BaselineShift = BaselineShift.ToString().ToLower();

				if ((string)Language != String.Empty)
					chr.Language = (Pageflex.Scripting.Language)Language;

				if ((string)ColorType != String.Empty)
					chr.TextColor = DefinedColor(Color, ColorType, Definition);
			}
			catch (Exception ex)
			{
				throw new Four51ActionsException(ex.Message, (string)ErrorMessage);
			}
		}

		public static void Divide(object NumberA, object NumberB, string SpecName, object NumberFormatCode, object ErrorMessage)
		{
			Break();
			try
			{
				double z = N(NumberA) / N(NumberB);
				Variable(SpecName).Value = z.ToString((string)NumberFormatCode);
			}
			catch (Exception ex)
			{
				throw new Four51ActionsException(ex.Message, (string)ErrorMessage);
			}
		}

		public static void MultiDivide(object Numbers, string SpecName, object NumberFormatCode, object ErrorMessage)
		{
			Break();
			try
			{
				double count = 0;
				object[] numbers = ParseArray(Numbers);
				foreach (object n in numbers)
				{
					count /= N(n);
				}
				Variable(SpecName).Value = count.ToString((string)NumberFormatCode);
			}
			catch (Exception ex)
			{
				throw new Four51ActionsException(ex.Message, (string)ErrorMessage);
			}
		}

		public static void EAN13(string SpecName, object ErrorMessage)
		{
			Break();
			try
			{
				double sum;
				double x = 0; // the odd numbered digits added then multiplied by 3
				double y = 0; // the even numbered digits added then subtracted from the next-highest multiple of ten
				string barcode = String.Empty;

				char[] chars = Variable(SpecName).Value.ToCharArray();

				if (chars.Length != 12)
					throw new Four51ActionsException("EAN13 barcode must be 12 digits");
				
				// string substitution for the 1st character
				barcode = CharReplacement(chars[0], BarcodeSymbology.EAN13).ToString();

				// string substitution for the left notch
				for (int i = 1; i < 6; i++)
				{
					barcode += ((char)(Char.GetNumericValue(chars[i]) + 65)).ToString();
				}

				barcode += "y";

				for (int i = 6; i <= chars.GetUpperBound(0); i++)
				{
					barcode += chars[i].ToString();
				}

				for (int i = 0; i <= chars.GetUpperBound(0); i++)
				{
					if ((i % 2) != 0)
						y += Convert.ToInt32(chars[i].ToString());
					else
						x += Convert.ToInt32(chars[i].ToString());
				}

				sum = (y * 3) + x;
				sum = (Math.Ceiling(sum / 10) * 10) - (sum);

				barcode += sum.ToString() + "z";

				Variable(SpecName).Value = barcode.ToString();
			}
			catch (Exception ex)
			{
				throw new Four51ActionsException(ex.Message, (string)ErrorMessage);
			}
		}

		public static void Equal(object NumberA, object NumberB, string SpecName, object ErrorMessage)
		{
			Break();
			try
			{
				Variable(SpecName).Value = N(NumberA) == N(NumberB) ? "true" : "false";
			}
			catch (Exception ex)
			{
				throw new Four51ActionsException(ex.Message, (string)ErrorMessage);
			}
		}

		public static void FormatDate(string SpecName, object DateFormatCode, object ErrorMessage)
		{
			Break();
			try
			{
				Variable(SpecName).Value = DateTime.Parse(Variable(SpecName).Value).ToString((string)DateFormatCode);
			}
			catch (Exception ex)
			{
				throw new Four51ActionsException(ex.Message, (string)ErrorMessage);
			}
		}

		public static void FormatNumber(string SpecName, object NumberFormatCode, object ErrorMessage)
		{
			Break();
			try
			{
				double val = N(Variable(SpecName).Value);
				Variable(SpecName).Value = val.ToString((string)NumberFormatCode);
			}
			catch (Exception ex)
			{
				throw new Four51ActionsException(ex.Message, (string)ErrorMessage);
			}
		}
		
		public static void FormatString(string SpecName, object Format, object Params, object ErrorMessage)
		{
			Break();
			try
			{
				Variable(SpecName).Value = String.Format((string)Format, ParseArray(Params));
			}
			catch (Exception ex)
			{
				throw new Four51ActionsException(ex.Message, (string)ErrorMessage);
			}
		}

		public static void FormatSpecValueFromToolbar(string SpecName, object ErrorMessage)
		{
			Break();
			try
			{
				Variable(SpecName).Value = ToolBar.Parse(Variable(SpecName).Value);
			}
			catch (Exception ex)
			{
				throw new Four51ActionsException(ex.Message, (string)ErrorMessage);
			}
		}

		public static void GetPositionIndex(string SpecName, object Text, object CharacterToFind, object StartPosition, object ErrorMessage)
		{
			Break();
			try
			{
				Variable(SpecName).Value = Text.ToString().IndexOf((string)CharacterToFind, (int)N(StartPosition)).ToString();
			}
			catch (Exception ex)
			{
				throw new Four51ActionsException(ex.Message, (string)ErrorMessage);
			}
		}

		public static void GreaterThan(object NumberA, object NumberB, string SpecName, object ErrorMessage)
		{
			Break();
			try
			{
				Variable(SpecName).Value = N(NumberA) > N(NumberB) ? "true" : "false";
			}
			catch (Exception ex)
			{
				throw new Four51ActionsException(ex.Message, (string)ErrorMessage);
			}
		}

		public static void If(string SpecName, object CompareA, object CompareB, object ResultYes, object ResultNo, object ErrorMessage)
		{
			Break();
			try
			{
				Variable(SpecName).Value = CompareA.Equals(CompareB) ? (string)ResultYes : (string)ResultNo;
			}
			catch (Exception ex)
			{
				throw new Four51ActionsException(ex.Message, (string)ErrorMessage);
			}
		}

		public static void InsertImage(object ImageElement, object Source, object ErrorMessage)
		{
			Break();
			try
			{
				Image img = (Image)Application.CurrentDocument.FindElement((string)ImageElement);
				img.Source = (string)Source;
				if (img.SourceResolved == null)
					throw new Exception("Image resource not found.");
			}
			catch (Exception ex)
			{
				throw new Four51ActionsException(ex.Message, (string)ErrorMessage);
			}
		}

		public static void InsertText(string SpecName, object Position, object Text, object ErrorMessage)
		{
			Break();
			try
			{
				Variable(SpecName).Value = Variable(SpecName).Value.Insert((int)N(Position), (string)Text);
			}
			catch (Exception ex)
			{
				throw new Four51ActionsException(ex.Message, (string)ErrorMessage);
			}
		}

		public static void Italic(string SpecName, object Character, object ErrorMessage)
		{
			Break();
			try
			{
				Variable(SpecName).Value = Variable(SpecName).Value.Replace((string)Character, String.Format("<_char italic='true'>{0}</_char>", (string)Character));
			}
			catch (Exception ex)
			{
				throw new Four51ActionsException(ex.Message, (string)ErrorMessage);
			}
		}

		public static void LastPositionIndex(string SpecName, object Text, object CharacterToFind, object ErrorMessage)
		{
			Break();
			try
			{
				Variable(SpecName).Value = Text.ToString().LastIndexOf((string)CharacterToFind).ToString();
			}
			catch (Exception ex)
			{
				throw new Four51ActionsException(ex.Message, (string)ErrorMessage);
			}
		}

		public static void LessThan(object NumberA, object NumberB, string SpecName, object ErrorMessage)
		{
			Break();
			try
			{
				Variable(SpecName).Value = N(NumberA) < N(NumberB) ? "true" : "false";
			}
			catch (Exception ex)
			{
				throw new Four51ActionsException(ex.Message, (string)ErrorMessage);
			}
		}

		public static void LowerCase(string SpecName, object ErrorMessage)
		{
			Break();
			try
			{
				Variable(SpecName).Value = Variable(SpecName).Value.ToLower();
			}
			catch (Exception ex)
			{
				throw new Four51ActionsException(String.Format("{0}{1}", ex.Message, (string)ErrorMessage != String.Empty ? Environment.NewLine + (string)ErrorMessage : String.Empty));
			}
		}

		public static void Multiply(object NumberA, object NumberB, string SpecName, object NumberFormatCode, object ErrorMessage)
		{
			Break();
			try
			{
				double z = N(NumberA) * N(NumberB);
				Variable(SpecName).Value = z.ToString((string)NumberFormatCode);
			}
			catch (Exception ex)
			{
				throw new Four51ActionsException(ex.Message, (string)ErrorMessage);
			}
		}

		public static void MultiMultiple(object Numbers, string SpecName, object NumberFormatCode, object ErrorMessage)
		{
			Break();
			try
			{
				double count = 0;
				object[] numbers = ParseArray(Numbers);
				foreach (object n in numbers)
				{
					count *= N(n);
				}
				Variable(SpecName).Value = count.ToString((string)NumberFormatCode);
			}
			catch (Exception ex)
			{
				throw new Four51ActionsException(ex.Message, (string)ErrorMessage);
			}
		}

		public static void PadEnd(string SpecName, object Count, object Character, object ErrorMessage)
		{
			Break();
			try
			{
				var text = Variable(SpecName).Value;
				var pad = text.Length + (int)N(Count);
				Variable(SpecName).Value = text.PadRight(pad, Convert.ToChar(Character));
			}
			catch (Exception ex)
			{
				throw new Four51ActionsException(ex.Message, (string)ErrorMessage);
			}
		}

		public static void PadStart(string SpecName, object Count, object Character, object ErrorMessage)
		{
			Break();
			try
			{
				var text = Variable(SpecName).Value;
				var pad = text.Length + (int)N(Count);
				Variable(SpecName).Value = text.PadLeft(pad, Convert.ToChar(Character));
			}
			catch (Exception ex)
			{
				throw new Four51ActionsException(ex.Message, (string)ErrorMessage);
			}
		}

		public static void PostNet(string SpecName,object AlternateStartStopChar, object ErrorMessage)
		{
			Break();
			try
			{
				int total = 0;
				int remainder = 0;
				int checkdigit = 0;

				string postcode = Variable(SpecName).Value.Replace("-", "");

				//#1
				IEnumerator chars = postcode.GetEnumerator();
				while (chars.MoveNext())
				{
					total += Convert.ToInt32(chars.Current.ToString());
				}
				//#2
				remainder = total % 10;
				//#3
				checkdigit = 10 - remainder;
				//#4 test
				if ((total + checkdigit) % 10 != 0)
					throw new Exception("The calculation failed proofing");

				Variable(SpecName).Value = String.Format("{2}{0}{1}{2}",
					postcode,
					checkdigit.ToString(),
					AlternateStartStopChar.ToString().Length > 0 ? AlternateStartStopChar.ToString() : "!");
			}
			catch (Exception ex)
			{
				throw new Four51ActionsException(ex.Message, (string)ErrorMessage);
			}
		}

		public static void Prefix(string SpecName, object Prefix, object ErrorMessage)
		{
			Break();
			try
			{
				Variable(SpecName).Value = String.Format("{0}{1}", Prefix, Variable(SpecName).Value);
			}
			catch (Exception ex)
			{
				throw new Four51ActionsException(ex.Message, (string)ErrorMessage);
			}
		}

		public static void ReplaceText(string SpecName, object OldCharacter, object NewCharacter, object ErrorMessage)
		{
			Break();
			try
			{
				Variable(SpecName).Value = Variable(SpecName).Value.Replace((string)OldCharacter, (string)NewCharacter);
			}
			catch (Exception ex)
			{
				throw new Four51ActionsException(ex.Message, (string)ErrorMessage);
			}
		}
		
		public static void ResizePage(string Width, string Height, object ErrorMessage)
		{
			Break();
			try
			{
				Document doc = Application.CurrentDocument;
				doc.PageHeight = Height;
				doc.PageWidth = Width;
			}
			catch (Exception ex)
			{
				throw new Four51ActionsException(ex.Message, (string)ErrorMessage);
			}
		}
		
		public static void ResizePageHeight(string Height, object ErrorMessage)
		{
			Break();
			try
			{
				Document doc = Application.CurrentDocument;
				doc.PageHeight = Height;
			}
			catch (Exception ex)
			{
				throw new Four51ActionsException(ex.Message, (string)ErrorMessage);
			}
		}
		
		public static void ResizePageWidth(string Width, object ErrorMessage)
		{
			Break();
			try
			{
				Document doc = Application.CurrentDocument;
				doc.PageWidth = Width;
			}
			catch (Exception ex)
			{
				throw new Four51ActionsException(ex.Message, (string)ErrorMessage);
			}
		}
		
		public static void ResizePageByPercentage(object Percentage, object ErrorMessage)
		{
			Break();
			try
			{
				Document doc = Application.CurrentDocument;
				string percent = Percentage.ToString().Replace("%", "").Replace(" ", "");

				object h = doc.PageHeight.GetType().GetProperty("Pt").GetValue(doc.PageHeight, null);
				decimal height = Convert.ToDecimal(h) * (Convert.ToDecimal(percent) * Convert.ToDecimal(.01));
				doc.PageHeight = String.Format("{0}pt", height.ToString());

				object w = doc.PageWidth.GetType().GetProperty("Pt").GetValue(doc.PageWidth, null);
				decimal width = Convert.ToDecimal(w) * (Convert.ToDecimal(percent) * Convert.ToDecimal(.01));
				doc.PageWidth = String.Format("{0}pt", width.ToString());
			}
			catch (Exception ex)
			{
				throw new Four51ActionsException(ex.Message, (string)ErrorMessage);
			}
		}

		public static void Select(string SpecName, object Case, object CaseArray, object ErrorMessage)
		{
			Break();
			try
			{
				string result = (string)ErrorMessage;

				foreach (String m in SelectCaseMatches(CaseArray))
				{
					string[] keypair = m.Split(new string[] { "=" }, StringSplitOptions.None);
					if (keypair[0] == (string)Case)
					{
						result = keypair[1];
					}
				}
				Variable(SpecName).Value = result;
			}
			catch (Exception ex)
			{
				throw new Four51ActionsException(ex.Message, (string)ErrorMessage);
			}
		}

		public static void ScaleImageToFill(object ImageElement, object ErrorMessage)
		{
			Break();
			try
			{
				Image img = (Image)Application.CurrentDocument.FindElement((string)ImageElement);

				Shape frame = (Shape)img.ParentElement;
				Measurement frameWidth = frame.Width;
				Measurement frameHeight = frame.Height;

				Measurement cWidth = img.Width;
				Measurement cHeight = img.Height;

				double hRatio = frameHeight / cHeight;
				double wRatio = frameWidth / cWidth;

				if (hRatio > wRatio)
				{
					Measurement newHeight = cHeight * hRatio;
					Measurement newWidth = (cWidth / cHeight) * newHeight;

					img.Height = newHeight;
					img.Width = newWidth;
				}
				else
				{
					Measurement newWidth = cWidth * wRatio;
					Measurement newHeight = (cHeight / cWidth) * newWidth;
					img.Width = newWidth;
					img.Height = newHeight;
				}

				cWidth = img.Width;
				cHeight = img.Height;
			}
			catch (Exception ex)
			{
				throw new Four51ActionsException(ex.Message, (string)ErrorMessage);
			}
		}

		public static void SelectImage(object ImageElement, object Case, object SourceArray, object ErrorMessage)
		{
			Break();
			try
			{
				string result = (string)ErrorMessage;

				foreach (String m in SelectCaseMatches(SourceArray))
				{
					string[] keypair = m.Split(new string[] { "=" }, StringSplitOptions.None);
					if (keypair[0] == (string)Case)
					{
						result = keypair[1];
					}
				}
				Image img = (Image)Application.CurrentDocument.FindElement((string)ImageElement);
				img.Source = result;
				if (img.SourceResolved == null)
					throw new Exception("Image resource not found.");
			}
			catch (Exception ex)
			{
				throw new Four51ActionsException(ex.Message, (string)ErrorMessage);
			}
		}
		
		public static void SharedAreaTemplate(object SpecName, object Name, object SharedPath, object ErrorMessage)
		{
			Break();
			try
			{
				SharedResource(SpecName, SharedPath).Value = (string)Name;
			}
			catch (Exception ex)
			{
				throw new Four51ActionsException(ex.Message, (string)ErrorMessage);
			}
		}
		
		public static void SharedImage(object ImageElement, object Source, object SharedPath, object ErrorMessage)
		{
			Break();
			try
			{
				Image img = (Image)Application.CurrentDocument.FindElement((string)ImageElement);
				img.Source = SharedUNCPath + (string)SharedPath + "\\" + (string)Source;
				if (img.SourceResolved == null)
					throw new Four51ActionsException("Shared resource not found");
			}
			catch (Exception ex)
			{
				throw new Four51ActionsException(ex.Message, (string)ErrorMessage);
			}
		}
		
		public static void SharedTemplate(object SpecName, object Source, object SharedPath, object ErrorMessage)
		{
			Break();
			try
			{
				SharedResource(SpecName, SharedPath).Value = (string)Source;
			}
			catch (Exception ex)
			{
				throw new Four51ActionsException(ex.Message, (string)ErrorMessage);
			}
		}
		
		public static void SharedText(object SpecName, object Source, object SharedPath, object ErrorMessage)
		{
			Break();
			try
			{
				SharedResource(SpecName, SharedPath).Value = (string)Source;
			}
			catch (Exception ex)
			{
				throw new Four51ActionsException(ex.Message, (string)ErrorMessage);
			}
		}

		public static void Subscript(string SpecName, object Character, object ErrorMessage)
		{
			Break();
			try
			{
				Variable(SpecName).Value = Variable(SpecName).Value.Replace((string)Character, String.Format("<_char supersub='subscript'>{0}</_char>", (string)Character));
			}
			catch (Exception ex)
			{
				throw new Four51ActionsException(ex.Message, (string)ErrorMessage);
			}
		}

		public static void SubString(string SpecName, object Start, object Length, object ErrorMessage)
		{
			Break();
			try
			{
				var text = Variable(SpecName).Value;
				var len = 0; var start = 0;
				if (((string)Length).Length > 0) N(Start);
				if (((string)Length).Length > 0) N(Length);
				Variable(SpecName).Value = text.Substring(start, len);
			}
			catch (Exception ex)
			{
				throw new Four51ActionsException(ex.Message, (string)ErrorMessage);
			}
		}

		public static void Subtract(object NumberA, object NumberB, string SpecName, object NumberFormatCode, object ErrorMessage)
		{
			Break();
			try
			{
				double z = N(NumberA) - N(NumberB);
				Variable(SpecName).Value = z.ToString((string)NumberFormatCode);
			}
			catch (Exception ex)
			{
				throw new Four51ActionsException(ex.Message, (string)ErrorMessage);
			}
		}

		public static void MultiSubtract(object Numbers, string SpecName, object NumberFormatCode, object ErrorMessage)
		{
			Break();
			try
			{
				double count = 0;
				object[] numbers = ParseArray(Numbers);
				foreach (object n in numbers)
				{
					count -= N(n);
				}
				Variable(SpecName).Value = count.ToString((string)NumberFormatCode);
			}
			catch (Exception ex)
			{
				throw new Four51ActionsException(ex.Message, (string)ErrorMessage);
			}
		}

		public static void Suffix(string SpecName, object Suffix, object ErrorMessage)
		{
			Break();
			try
			{
				Variable(SpecName).Value = String.Format("{0}{1}", Variable(SpecName).Value, Suffix);
			}
			catch (Exception ex)
			{
				throw new Four51ActionsException(ex.Message, (string)ErrorMessage);
			}
		}

		public static void Superscript(string SpecName, object Character, object ErrorMessage)
		{
			Break();
			try
			{
				Variable(SpecName).Value = Variable(SpecName).Value.Replace((string)Character, String.Format("<_char supersub='superscript'>{0}</_char>", (string)Character));
			}
			catch (Exception ex)
			{
				throw new Four51ActionsException(ex.Message, (string)ErrorMessage);
			}
		}

		public static void Trim(string SpecName, object Characters, object ErrorMessage)
		{
			Break();
			try
			{
				var text = Variable(SpecName).Value;
				Variable(SpecName).Value = text.Trim(((string)Characters).ToCharArray());
			}
			catch (Exception ex)
			{
				throw new Four51ActionsException(ex.Message, (string)ErrorMessage);
			}
		}

		public static void TrimEnd(string SpecName, object Characters, object ErrorMessage)
		{
			Break();
			try
			{
				var text = Variable(SpecName).Value;
				Variable(SpecName).Value = text.TrimEnd(((string)Characters).ToCharArray());
			}
			catch (Exception ex)
			{
				throw new Four51ActionsException(ex.Message, (string)ErrorMessage);
			}
		}

		public static void TrimStart(string SpecName, object Characters, object ErrorMessage)
		{
			Break();
			try
			{
				var text = Variable(SpecName).Value;
				Variable(SpecName).Value = text.TrimStart(((string)Characters).ToCharArray());
			}
			catch (Exception ex)
			{
				throw new Four51ActionsException(ex.Message, (string)ErrorMessage);
			}
		}

		public static void UPCVersionA(string SpecName, object ErrorMessage)
		{
			Break();
			try
			{
				double sum;
				double x = 0; // the odd numbered digits added then multiplied by 3
				double y = 0; // the even numbered digits added then subtracted from the next-highest multiple of ten
				string barcode = String.Empty;

				char[] chars = Variable(SpecName).Value.ToCharArray();

				if (chars.Length != 11)
					throw new Four51ActionsException("UPC-A barcode must be 11 digits");
				
				// string substitution for the 1st character
				barcode = CharReplacement(chars[0], BarcodeSymbology.UPCA).ToString();

				// string substitution for the left notch
				for (int i = 1; i < 6; i++)
				{
					barcode += ((char)(Char.GetNumericValue(chars[i]) + 65)).ToString();
				}

				// stop start char for middle of barcode
				barcode += "y";

				// the third set does not get encoded
				for (int i = 6; i <= chars.GetUpperBound(0); i++)
				{
					barcode += chars[i].ToString();
				}

				// calculate checksum
				for (int i = 0; i <= chars.GetUpperBound(0); i++)
				{
					if ((i % 2) != 0)
						y += Convert.ToInt32(chars[i].ToString());
					else
						x += Convert.ToInt32(chars[i].ToString());
				}

				sum = (x * 3) + y;
				sum = (10 - (sum % 10)) % 10;

				barcode += String.Format("{0}z{1}",
					((char)(sum + 107)).ToString(),
					CharReplacement(sum.ToString().ToCharArray()[0], BarcodeSymbology.UPCA_checkdigit).ToString());

				Variable(SpecName).Value = barcode.ToString();
			}
			catch (Exception ex)
			{
				throw new Four51ActionsException(ex.Message, (string)ErrorMessage);
			}
		}

		public static void Underline(string SpecName, object Character, object ErrorMessage)
		{
			Break();
			try
			{
				Variable(SpecName).Value = Variable(SpecName).Value.Replace((string)Character, String.Format("<_char underline='true'>{0}</_char>", (string)Character));
			}
			catch (Exception ex)
			{
				throw new Four51ActionsException(String.Format("{0}{1}", ex.Message, (string)ErrorMessage != String.Empty ? Environment.NewLine + (string)ErrorMessage : String.Empty));
			}
		}

		public static void UpperCase(string SpecName, object ErrorMessage)
		{
			Break();
			try
			{
				Variable(SpecName).Value = Variable(SpecName).Value.ToUpper();
			}
			catch (Exception ex)
			{
				throw new Four51ActionsException(ex.Message, (string)ErrorMessage);
			}
		}
		
	#endregion

		internal static float N(object X)
		{
			if ((string)X == "") return 0;
			return float.Parse((string)X);
		}

		internal struct BarcodeSymbology
		{
			public static string[] EAN13 = { "�|x", "�|x", "�|x", "�|x", "�|x", "�|x", "�|x", "�|x", "�|x", "�|x" };
			public static string[] UPCA = { "U|xa", "[|xb", "V|xc", "W|xd", "X|xe", "Y|xf", "Z|xg", "u|xh", "\\|xi", "]|xj" };
			public static string[] UPCA_checkdigit = { "U", "[", "V", "W", "X", "Y", "Z", "u", "\\", "]" };
		}

		internal static string CharReplacement(char code, string[] symb)
		{
			List<string> chars = new List<string>(symb);
			return chars[Convert.ToInt32(code.ToString())];
		}
		
		internal enum ColorTypes
		{
			Name, Rgb, Cmyk
		}

		internal static string SharedUNCPath
		{
			get	{ return Variable("four51sharedpath").Value; } 
		}

		internal static Variable Variable(string var)
		{
			try
			{
				return Application.GetVariable(var);
			}
			catch (Pageflex.Scripting.Exceptions.VariableNotFoundException ex)
			{
				throw new Four51ActionsException(ex.Message);
			}
		}

		internal static Variable SharedResource(object variable, object sharedPath)
		{
			try
			{
				Variable var =  Application.GetVariable((string)variable);
				var.Value = SharedUNCPath + (string)sharedPath + "\\";
				return var;
			}
			catch (Pageflex.Scripting.Exceptions.VariableNotFoundException ex)
			{
				throw new Four51ActionsException(ex.Message);
			}
		}

		internal static object[] ParseArray(object SourceArray)
		{
			Regex reg = new Regex("{(?<tag>.*?)}");
			MatchCollection matches = reg.Matches((string)SourceArray);
			var str = new object[matches.Count]; var i = 0;
			foreach (Match m in matches)
			{
				try
				{
					str[i] = Variable(m.Groups["tag"].Value).Value;
				}
				catch
				{
					str[i] = m.Groups["tag"].Value;
				}
				i++;
			}
			return str;
		}

		internal static string[] SelectCaseMatches(object SourceArray)
		{
			Regex reg;
			string pattern = "{(?<tag>.*?)}"; // format = {key=pair}

			reg = new Regex(pattern, RegexOptions.Singleline);
			return reg.Split((string)SourceArray);
		}

		internal static void Break()
		{
	#if DEBUG
			System.Diagnostics.Debugger.Break();
	#endif
		}
		
		internal static string DefinedColor(object Color, object ColorType, object Definition)
		{
			uint val;
			object type;

			bool IsNamed = !(UInt32.TryParse(ColorType.ToString(), out val));
			if (IsNamed)
				type = Enum.Parse(typeof(ColorTypes), (string)ColorType, true);
			else
				type = (ColorTypes)Convert.ToUInt32(ColorType);

			switch ((ColorTypes)type)
			{
				case ColorTypes.Cmyk:
					return new CmykColor((string)Color, (string)Definition).ToString();
				case ColorTypes.Rgb:
					return new RgbColor((string)Color, (string)Definition).ToString();
				case ColorTypes.Name:
					return (string)Color;
				default:
					throw new Four51ActionsException("Color type or definition not valid.");
			}
		}

		internal class Four51ActionsException : Exception
		{
			private string _message;
			private string _exceptionMsg;
			
			public Four51ActionsException(string exceptionMessage, string CustomErrorMessage)
			{
				_message = CustomErrorMessage;
				_exceptionMsg = exceptionMessage;
			}
			
			public Four51ActionsException(string CustomErrorMessage)
			{
				_message = CustomErrorMessage;
			}

			public override string Message
			{
				get
				{
					return String.Format("{0}{1}", _exceptionMsg, _message != String.Empty ? Environment.NewLine + _message: String.Empty);
				}
			}
		}

		internal class RgbColor
		{
			private string _name;
			private string _rgb;
			private uint[] Rgb
			{
				get
				{
					string[] input = _rgb.ToString().Split(new string[] { "-" }, StringSplitOptions.None);
					uint[] values = { Convert.ToUInt32(input[0]), Convert.ToUInt32(input[1]), Convert.ToUInt32(input[2]) };
					return values;
				}
			}

			public RgbColor(string Name, string Values)
			{
				_name = Name;
				_rgb = Values;

				//get defined color and apply rgb values
				Color color = Application.CurrentDocument.GetColor(_name);
				color.RgbValues = this.Rgb;
			}

			public override string ToString()
			{
				return _name;
			}
		}

		internal class CmykColor
		{
			private string _name;
			private string _cmyk;
			public double[] Cmyk
			{
				get
				{
					string[] input = _cmyk.ToString().Split(new string[] { "-" }, StringSplitOptions.None);
					double[] values = { N(input[0]), N(input[1]), N(input[2]), N(input[3]) };
					return values;
				}
			}

			public CmykColor(string Name, string Values)
			{
				_name = Name;
				_cmyk = Values;

				//get defined color and apply cmyk values
				Color color = Application.CurrentDocument.GetColor(_name);
				color.CmykValues = this.Cmyk;
			}

			public override string ToString()
			{
				return _name;
			}
		}
	}
}
